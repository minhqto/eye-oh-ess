//
//  IsPrintable.swift
//  Assignment1
//
//  Created by Minh To on 2021-09-25.
//

import Foundation

protocol isPrintable {
    func show() -> Void
}
