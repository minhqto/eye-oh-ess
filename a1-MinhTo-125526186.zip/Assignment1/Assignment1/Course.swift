//
//  Course.swift
//  Assignment1
//
//  Created by Minh To on 2021-09-21.
//

import Foundation

struct Course {
    public var courseTitle: String
    public var grade: Int
}
